# RoboRacing Electrical
This is a repository for the RoboJackets' RoboRacing Electrical team.

## bigoli
Contains current files associated with Bigoli, including the mbed shield and system diagram (coming soon).

## macaroni
Contains current files associated with Macaroni, including the system diagram (coming soon).

## discont
Contains old files no longer in use on the current robots.

